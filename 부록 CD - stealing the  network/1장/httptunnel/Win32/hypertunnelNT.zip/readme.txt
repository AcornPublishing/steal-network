readmne

NT binaries, built with Cygwin 20.b1, httptunnel version 2.6 and 3.0 
Sample working lines: 

htc -B 20k -c 20k -F 8000 -D 1 -P proxy:port htshost 

hts -c 20k -F localhost:23 -D 1 

For full details, see httptunnel home page. 

NT binaries 

Last updated Jan 14 2000 

t_BR sv_SE httptunnel 3.0.1 3 
Tunnelizes connection via http httptunnel creates a bidirectional virtual data path tunnelled in HTTP requests. The HTTP requests can be sent via an HTTP proxy if so desired.  This can be useful for users behind restrictive firewalls. If WWW access is allowed through a HTTP proxy, it's possible to use httptunnel and, say, telnet or PPP to connect to a computer outside the firewall.  httptunnel is written and maintained by Lars Brinkhoff. See the file
AUTHORS for more information about contributors to this package. 

 (Cl�udio Sampaio) <patola@linuxbr.com.br> System Environment/Daemons Ambiente do Sistema/Servidores http://www.nocrew.org/software/httptunnel.html Linux i386 /usr/doc/httptunnel-3.0.1 /usr/doc/httptunnel-3.0.1/AUTHORS /usr/doc/httptunnel-3.0.1/COPYING /usr/doc/httptunnel-3.0.1/ChangeLog /usr/doc/httptunnel-3.0.1/DISCLAIMER /usr/doc/httptunnel-3.0.1/FAQ /usr/doc/httptunnel-3.0.1/HACKING /usr/doc/httptunnel-3.0.1/INSTALL /usr/doc/httptunnel-3.0.1/NEWS /usr/doc/httptunnel-3.0.1/README /usr/doc/httptunnel-3.0.1/TODO /usr/local/bin/htc /usr/local/bin/hts /usr/local/man/man1/htc.1 /usr/local/man/man1/hts.1 