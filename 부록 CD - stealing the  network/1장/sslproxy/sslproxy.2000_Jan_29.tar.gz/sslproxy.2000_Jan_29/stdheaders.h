/*
 * Name: stdheaders.h
 * Project: SSL Proxy
 * Author: Christian Starkjohann <cs@obdev.at>
 * Creation Date: 1998-06-12
 * Tabsize: 4
 * Copyright: (c) 1998 by Christian Starkjohann, all rights reserved.
 *    sslproxy is distributed under the terms of the GNU General Public
 *    License (GPL) version 2.0.
 * This Revision: $Id: stdheaders.h,v 1.1.1.1 1998/06/14 20:46:41 cs Exp $
 */

/*
General Description:
This header includes all system headers that are needed. 
*/

#ifndef __STDHEADERS_H_INCLUDED__
#define __STDHEADERS_H_INCLUDED__


#ifdef NeXT
#	include <libc.h>
	extern int	errno;
	/* the following should have been in sys/param.h: */
	extern char	*realpath(char *file_name, char *resolved_name);
#endif

#if defined __sgi
#	include <strings.h>
#endif

#if defined SOLARIS2
#	define PORTMAP
#endif

#if defined SUNOS
	extern int	getopt(int argc, char *const *argv, const char *options);
	extern char	*optarg;
	extern int	optind;
#	define	memmove(dest, src, len)		bcopy(src, dest, len)
#endif

#ifdef __CYGWIN32__
#include <getopt.h>
#endif

union wait;		/* forward declaration, needed for AIX to suppress warnings */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/errno.h>
#include <errno.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <sys/param.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <syslog.h>
#include <ctype.h>
#include <sys/signal.h>
#include <signal.h>
#include <pwd.h>
#include <grp.h>

#ifndef NULL
#	define	NULL	((void *)0)
#endif

#ifndef INADDR_NONE	/* Address indicating an error return. */
#	define	INADDR_NONE		0xffffffffUL
#endif

#ifndef FNDELAY
#	ifdef O_NDELAY
#		define  FNDELAY O_NDELAY
#	else
#		define  FNDELAY O_NONBLOCK
#	endif
#endif

/* ------------------------------------------------------------------------- */

#endif /* __STDHEADERS_H_INCLUDED__ */
