#GPL
#GPL  libwhisker copyright 2000,2001,2002 by rfp.labs
#GPL
#GPL  This program is free software; you can redistribute it and/or
#GPL  modify it under the terms of the GNU General Public License
#GPL  as published by the Free Software Foundation; either version 2
#GPL  of the License, or (at your option) any later version.
#GPL
#GPL  This program is distributed in the hope that it will be useful,
#GPL  but WITHOUT ANY WARRANTY; without even the implied warranty of
#GPL  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GPL  GNU General Public License for more details.
#GPL

=pod

=head1 ++ Sub package: easy

The 'easy' subpackage contains many high-level/simple functions to
do basic web tasks.  This should make it easier to use libwhisker
to do basic tasks.

=cut

########################################################################

=pod

=head1 - Function: LW::get_page
  
Params: $url [, \%hin_request]
Return: $code, $data ($code will be set to undef on error, $data will
			contain error message)

This function will fetch the page at the given URL, and return the HTTP response code
and page contents.  Use this in the form of:
($code,$html)=LW::get_page("http://host.com/page.html")

The optional %hin_request will be used if supplied.  This allows you to set
headers and other parameters.

=cut

sub get_page {
	my ($URL,$hr)=(shift,shift);
	return (undef,"No URL supplied") if(length($URL)==0);

	my (%req,%resp);
	my $rptr;

	if(defined $hr && ref($hr)){
		$rptr=$hr;
	} else {
		$rptr=\%req;
		LW::http_init_request(\%req);
	}

	LW::utils_split_uri($URL,$rptr); # this is newer >=1.1 syntax
	LW::http_fixup_request($rptr);

	if(http_do_request($rptr,\%resp)){
		return (undef,$resp{'whisker'}->{'error'});
	}

	return ($resp{'whisker'}->{'code'}, $resp{'whisker'}->{'data'});
}

########################################################################

=pod

=head1 - Function: LW::get_page_to_file
  
Params: $url, $filepath [, \%hin_request]
Return: $code ($code will be set to undef on error)

This function will fetch the page at the given URL, place the resulting HTML
in the file specified, and return the HTTP response code.  The optional
%hin_request hash sets the default parameters to be used in the request.

NOTE: libwhisker does not do any file checking; libwhisker will open the
supplied filepath for writing, overwriting any previously-existing files.
Libwhisker does not differentiate between a bad request, and a bad file
open.  If you're having troubles making this function work, make sure
that your $filepath is legal and valid, and that you have appropriate
write permissions to create/overwrite that file.

=cut

sub get_page_to_file {
	my ($URL, $filepath, $hr)=@_;

	return undef if(length($URL)==0);
	return undef if(length($filepath)==0);

	my (%req,%resp);
	my $rptr;

	if(defined $hr && ref($hr)){
		$rptr=$hr;
	} else {
		$rptr=\%req;
		LW::http_init_request(\%req);
	}

	LW::utils_split_uri($URL,$rptr); # this is newer >=1.1 syntax
	LW::http_fixup_request($rptr);

	if(http_do_request($rptr,\%resp)){
		return undef;
	}
	open(OUT,">$filepath") || return undef;
	binmode(OUT); # stupid Windows
	print OUT $resp{'whisker'}->{'data'};
	close(OUT);

	return $resp{'whisker'}->{'code'};
}

########################################################################

=pod

=head1 - Function: LW::upload_file
  
Params: $url, $filepath, $paramname [, \%hin_request]
Return: $code ($code will be set to undef on error)

This function will upload the specified $file to the given $url as
the parameter named $paramname via a multipart POST request.  The 
optional $hin_request hash lets you set any other particular request
parameters.

NOTE: this is a highly simplied function for basic uploads.  If you
need to do more advanced things like set other multipart form
parameters, send multiple files, etc, then you will need to use the
normal API to do it yourself.

=cut

sub upload_file {
	my ($URL, $filepath, $paramname, $hr)=@_;

	return undef if(length($URL)      ==0);
	return undef if(length($filepath) ==0);
	return undef if(length($paramname)==0);
	return undef if(!(-e $filepath && -f $filepath));

	my (%req,%resp,%multi);
	my $rptr;

	if(defined $hr && ref($hr)){
		$rptr=$hr;
	} else {
		$rptr=\%req;
		LW::http_init_request(\%req);
	}

	LW::utils_split_uri($URL,$rptr); # this is newer >=1.1 syntax
	$rptr{'whisker'}->{'method'}='POST';
	LW::http_fixup_request($rptr);

	LW::multipart_setfile(\%multi,$filepath,$paramname);
	LW::multipart_write(\%multi,$rptr);

	if(http_do_request($rptr,\%resp)){
		return undef;
	}

	return $resp{'whisker'}->{'code'};
}

########################################################################

=pod

=head1 - Function: LW::download_file
  
Params: $url, $filepath [, \%hin_request]
Return: $code ($code will be set to undef on error)

LW::download_file is just an alias for LW::get_page_to_file().

=cut

sub download_file {
	goto &LW::get_page_to_file;
}

########################################################################

