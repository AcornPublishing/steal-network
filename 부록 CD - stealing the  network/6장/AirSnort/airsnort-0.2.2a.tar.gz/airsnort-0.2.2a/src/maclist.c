/*
    This file is part of AirSnort.

    AirSnort is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    AirSnort is distributed in the hope that it will be useful,
      but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with AirSnort; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include "maclist.h"

int bssidMatch(const unsigned char *bssid1, const unsigned char *bssid2);

MacStruct *newMac(const unsigned char *mac, MacStruct *next) {
   MacStruct *result = calloc(1, sizeof(MacStruct));
   memcpy(result->mac, mac, 6);
   //first = last = time(NULL);
   result->next = next;
}

int addMac(MacList *macList, const unsigned char *mac) {
   if (findMac(macList, mac) == NULL) {
      macList->clients[mac[5]] = newMac(mac, macList->clients[mac[5]]);
      return 1;
   }
   return 0;
}

int removeMac(MacList *macList, const unsigned char *mac) {
   MacStruct *m = macList->clients[mac[5]], *p = NULL;
   for (; m; m = m->next) {
      if (bssidMatch(m->mac, mac)) {
         if (p) {
            p->next = m->next;
         }
         else {
            macList->clients[mac[5]] = m->next;
         }
         break;
      }
      p = m;
   }
   if (m) {
      free(m);
   };
   return m != NULL;
}

MacStruct *findMac(MacList *macList, const unsigned char *mac) {
   MacStruct *m = macList->clients[mac[5]];
   for (; m; m = m->next) {
      if (bssidMatch(m->mac, mac)) {
         break;
      }
   }
   return m;
}


