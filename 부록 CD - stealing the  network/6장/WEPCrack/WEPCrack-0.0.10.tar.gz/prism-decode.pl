#!/usr/bin/perl

# prism-decode.pl - 802.11 protocol decoder for prismdump output. Either specify prismdump capture file or pipe prismdump
# output to script
# Anton T. Rager - 08/17/2001

# Known bugs : readtoend() is broken.  Data packets with ff:ff:ff:ff will f-up the next few packets. Need to read pkt len and
# seek to end

$pcapfile=@ARGV[0];
if ($pcapfile) {
	if (!-f $pcapfile) {
		die("File not found\n");
	}
	open(INFILE, $pcapfile);
} else {
	open(INFILE, "-");
}


# Look to see if valid pcap file and determine Endian-ness
for ($i=0; $i<4; $i++) {
	$inchar=getc(INFILE);
	$pcapformat=$pcapformat . $inchar;
}
$pcap_hex=unpack('H*', $pcapformat);
print("\n\nPcap Header : $pcap_hex\n");

if ($pcap_hex eq "d4c3b2a1") {
	print("Big Endian\n");
	$big=1;
} elsif ($pcap_hex eq "a1b2c3d4") {
	print("Little Endian\n");
	$big=0;
} else {
	die("Not Pcap?\n");
}

# Jump over rest of file header
for ($i=0; $i<20; $i++) {
	$inchar=getc(INFILE);

}
                                                                                                                       $caplen_val=unpack('V*', $caplen);

# 1st 4 bytes: #MS
# 2nd 4 bytes: #secs         	
# 3rd 4 bytes: caplen
# 4th 4 bytes: pktlen
# use caplen value for readahead.
$caplen="";
for ($i=0; $i<4; $i++) {
	$inchar=getc(INFILE);
}
for ($i=0; $i<4; $i++) {
	$inchar=getc(INFILE);
}
#Get actual captured pkt len
for ($i=0; $i<4; $i++) {
	$inchar=getc(INFILE);
	$caplen=$caplen . $inchar;
}
for ($i=0; $i<4; $i++) {
	$inchar=getc(INFILE);
	$rptlen=$rptlen . $inchar;
}
# convert len from char to little endian long.
if ($big) {
	$caplen_val=unpack('V*', $caplen);
       	$rpt_val=unpack('V*', $rptlen);
} else {
	$caplen_val=unpack('N*', $caplen);
}
print("\n\nnext pkt capture length : $caplen_val, next pkt rpt length : $rpt_val\n");



while (!eof(INFILE)) {

	print("\n\n802.11 Header:\n");
	print("\n\tFrame CTRL: ");

	$inchar=ord(getc(INFILE));
	$frametype=$inchar;
	$inchar=ord(getc(INFILE));
	$flags=$inchar;

	#print("\n\tDuration: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
	}

	if ($frametype eq 0x80) {
		print("\n\tBeacon Frame:\n");
		&beacon();
	} elsif ($frametype eq 0x08) {
		print("\n\tData Frame:\n");
		&dataframe();
	} elsif ($frametype eq 0x00) {
		print("\n\tAssociation Request Frame:\n");
		#&readtoend();
		&asn_req();
	} elsif ($frametype eq 0x10) {
		print("\n\tAssociation Response Frame:\n");
		&asn_rpl();
	} elsif ($frametype eq 0x40) {
		print("\n\tProbe Request Frame:\n");
		&probe_req();
	} elsif ($frametype eq 0x50) {
		print("\n\tProbe Response Frame:\n");
		&probe_rpl();
	} elsif ($frametype eq 0xb0) {
		print("\n\tAuthentication Frame:\n");
		&auth();
	} elsif ($frametype eq 0xc0) {
		print("\n\tDisAssociation Frame:\n");
		&de_asn ();
	} elsif ($frametype eq 0xd4) {
		print("\n\tACK Frame - Skipping\n");
		&readtoend($caplen_val-5);
		# ACK frame : no src, dst, bssid fields.
		# ACK frame =  Type, flags, duration [2 bytes], rcv addr [6 bytes]
	} else {
		print("\n\tOther Frame - Skipping\n");
		&readtoend($caplen_val-5);
		# RTS - 0xb4
		# ReAssociation Request -
		# DeAuth -
	}
	

	# jump to next record
#	for ($i=0; $i<16; $i++) {
#		$inchar=ord(getc(INFILE));
#	}

	# 1st 4 bytes: #MS
	# 2nd 4 bytes: #secs
	# 3rd 4 bytes: caplen
	# 4th 4 bytes: pktlen
	# use caplen value for readahead.
	$caplen="";
	$rptlen="";
	for ($i=0; $i<4; $i++) {
		$inchar=getc(INFILE);
	}
	for ($i=0; $i<4; $i++) {
		$inchar=getc(INFILE);
	}
	for ($i=0; $i<4; $i++) {
		$inchar=getc(INFILE);
		$caplen=$caplen . $inchar;
	}
	for ($i=0; $i<4; $i++) {
		$inchar=getc(INFILE);
		$rptlen=$rptlen . $inchar;
	}

	if ($big) {
		$caplen_val=unpack('V*', $caplen);
        	$rpt_val=unpack('V*', $rptlen);
	} else {
		$caplen_val=unpack('N*', $caplen);
	}
	print("\n\nnext pkt capture length : $caplen_val, next pkt rpt length : $rpt_val\n");
	

}
exit;



sub beacon() {

	&gen_header();

	print("\nFixed Parameters:\n");
	for ($i=0; $i<10; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	print("\n\tCapability Flags: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	&tagparms();

}


sub dataframe(){

	&gen_header();

	# ----- Start Reading Data: WEP 1st 3bytes IV, 4th should be 0, 5th should 1st encr output
	print("\nIV: ");
	for ($x=0; $x<3; $x++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\nIV Options: ");
	$inchar=ord(getc(INFILE));
	printf("%02x", $inchar);	

	print("\nEncr Byte1: ");

	$inchar=ord(getc(INFILE));
	printf("%02x", $inchar);

	#read to end of record [ff-ff-ff-ff -- then, read next record [jump ahead 16bytes?]
	&readtoend($caplen_val-30);
}


sub asn_req () {

	&gen_header();

	# fixed : capability [2B], Listen Int[2B]
	print("\n\tCapability Flags: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tListen Interval: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	&tagparms();
}

sub asn_rpl () {

	&gen_header();

	# fixed : capability [2B], Status Code [2B], Association ID [2B]
	print("\n\tCapability Flags: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tStatus Code: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tAssociation ID: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	&tagparms();
}

sub probe_req () {
	&gen_header();
	&tagparms();
}

sub probe_rpl () {
	&gen_header();
	
	# fixed : timestamp [8B], beacon int [2B], capability [2B]
	print("\nFixed Parameters:\n");
	for ($i=0; $i<10; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	print("\n\tCapability Flags: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	&tagparms();
}

sub auth () {

	&gen_header();

	# fixed : Auth ALG [2B], Auth Seq [2B], Status Code [2B]
	print("\n\tAuth ALG: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tAuth Seq: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tStatus Code: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	for ($i=0; $i<4; $i++) {
		$inchar=getc(INFILE);
		#printf("%02x", $inchar);
	}

}

sub de_asn () {
	&gen_header();
	#fixed : Reason Code [2B]
	print("\n\tReason Code: ");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}	
	for ($i=0; $i<4; $i++) {
		$inchar=getc(INFILE);
		#printf("%02x", $inchar);
	}
}

sub gen_header() {

	print("\n\tDest Addr: ");
	for ($i=0; $i<6; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tSrc Addr: ");
	for ($i=0; $i<6; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
	print("\n\tBSSID Addr: ");
	for ($i=0; $i<6; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}

	print("\n");
	for ($i=0; $i<2; $i++) {
		$inchar=ord(getc(INFILE));
		printf("%02x", $inchar);
	}
}

sub readtoend {

	# Nasty kludge to read to end of frame. End of frame is FF:FF:FF:FF.  Review 802.11 spec for better method
	# doesn't always work -- if data packet has FF:FF:FF:FF in it, next few decodes are f'd up.
        my @passed = @_;

	print("Passed val : $passed[0]\n");
#	$endpkt=0;

	for ($i=0; $i<$passed[0]+1; $i++) {
		$inchar=getc(INFILE);
	
	}	
#	while (!$endpkt) {
#		$inchar=ord(getc(INFILE));
#		if ($inchar eq 255) {
#			$inchar=ord(getc(INFILE));	
#			if ($inchar eq 255) {
#				$inchar=ord(getc(INFILE));		
#				if ($inchar eq 255) {
#					$inchar=ord(getc(INFILE));		
#					if ($inchar eq 255) {
#						$endpkt=1;
#					}
#				}
#			}
#		}
#	}
}

sub tagparms() {

	print("\nTagged Parameters: ");
	$endpkt=0;
	while (!$endpkt) {
		$inchar=ord(getc(INFILE));
		if ($inchar eq 0x00) {
			print("\n\tSSID: ");
			$inchar=ord(getc(INFILE));
			$numchars=$inchar;
			for ($x=0; $x < $numchars; $x++) {
				$inchar=getc(INFILE);	
				print("$inchar");
			}
		}
		elsif ($inchar eq 0x01) {
			print("\n\tSupported Rates: ");
			$inchar=ord(getc(INFILE));
			$numchars=$inchar;
			for ($x=0; $x < $numchars; $x++) {
				$inchar=ord(getc(INFILE));	
				printf("%02x", $inchar);
			}
		}
		elsif ($inchar eq 0x03) {
			print("\n\tChannel: ");
			$inchar=ord(getc(INFILE));
			$numchars=$inchar;
			for ($x=0; $x < $numchars; $x++) {
				$inchar=ord(getc(INFILE));	
				printf("%02x", $inchar);
			}

		}
		elsif ($inchar eq 0xff) {
			print("\n\tEnd Marker: ");
			$inchar=ord(getc(INFILE));
			$numchars=$inchar;
			if ($numchars eq 255) {
				$numchars=2;
				$endpkt=1;
			}
			for ($x=0; $x < 2; $x++) {
				$inchar=ord(getc(INFILE));	
				printf("%02x", $inchar);
			}
		} else {
			print("\n\tUnknown Tag: ");
			$inchar=ord(getc(INFILE));
			$numchars=$inchar;
			for ($x=0; $x < $numchars; $x++) {
				$inchar=ord(getc(INFILE));	
				printf("%02x", $inchar);
			}
		}
	}
	print("\n");

}

