#!/usr/bin/perl

# basic RC4 keyscheduler and PRGA routine that chooses IVs known to be weak (A+3, N-1, X) and encrypts one byte with key supplied from
# command line. An output file is created in the current directory that contains IVs with a corresponding encrypted byte as well as an
# indicator for secret key size
#
# Choice of the (A+3, N-1, X) keys is based on the paper "Weakness in the Key Scheduling Algorithm of RC4" by
# Scott Fluhrer, Itsik Mantin, and Adi Shamir
#

# By : Anton T. Rager - 08/09/2001-08/12/2001
#      a_rager@yahoo.com

$findhost=@ARGV[0];
if (!$findhost) {
	print("Usage:  WeakIVGen.pl <Key1:Key2:Key3:Key4:Key5...Keyn>\n\nWhere Keyx is key byte in decimal\nAnd : is delimiter for each byte [40bit=5bytes, 128bit=11bytes]\n");
	exit;
}


$i=0;
$j=0;
$ik=0;
$x=0;

@inkey=split(":", @ARGV[0]);

@IV = (3, 255, 0);

# 802.2 SNAP Header should be 1st plaintext byte of WEP packet
@text = (0xaa);

# Keysize 11 byte or 5 byte
$keysize=scalar(@inkey);
$bitsize=$keysize*8;

print("Keysize = $keysize\[$bitsize bits\]\n");

open(OUTFILE, ">IVFile.log");

print("$keysize\n");
print(OUTFILE "$keysize\n");

$keylen = $keysize+3;

for ($B=0; $B < $keysize; $B++) {
	#print("$B\n");

	

	for ($loop1=0; $loop1 < 256 ; $loop1++) {
		$IV[2]=$loop1;
	#  for ($loop2=0; $loop2 < 10; $loop2++) {
		$IV[0]=$B+3;
	#	$IV[0]=$loop2;
                for ($i=0; $i < $keylen; $i++) {
			if ($i < 3) {
				$Key[$i]=$IV[$i];
			} else {
				$Key[$i]=$inkey[$i-3];
			}

		}


		$i=0;
		$j=0;
		$ik=0;

		for ($i=0; $i<256; $i++) {
			$S[$i]=$i;
			if ($ik > $keylen-1) {
				$ik=0;
			}
			$Key[$i]=$Key[$ik];
			$ik++;
		}

		for ($i=0; $i<256; $i++) {
			$j=($j+$S[$i]+$Key[$i]) % 256;
			$temp = $S[$i];
			$S[$i] = $S[$j];
			$S[$j] = $temp;
		}

		# 1 byte thru PRGA
		$i=0;
		$j=0;
		$i=($i+1) % 256;
		$j=($j + $S[$i]) % 256;
		$temp=$S[$i];
		$S[$i]=$S[$j];
		$S[$j]=$temp;
		$t=($S[$i]+$S[$j]) % 256;
		$K=$S[$t];
		$encr=$text[0] ^ $K;
		$S3Calc = $text[0] ^ $encr;
		print("$IV[0] $IV[1] $IV[2] $encr\n");
		print(OUTFILE "$IV[0] $IV[1] $IV[2] $encr\n");



	}

}
print("\n");
close(OUTFILE);