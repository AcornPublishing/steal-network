#!/usr/bin/perl

# prism-getIV.pl - script to parse prismdump output and look for IVs that match possible weak IV/Key pairs.
# Anton T. Rager - 08/17/2001


$pcapfile=@ARGV[0];
if ($pcapfile) {
	if (!-f $pcapfile) {
		die("File not found\n");
	}
	open(INFILE, $pcapfile);
} else {
	open(INFILE, "-");
}

#open(LSBFILE, ">LSB-IVFile.log");
open(MSBFILE,">IVFile.log");
#open(FULLFILE,">LSB-IVpayload.log" );

# hardcoded fo 40bit WEP
print(MSBFILE "5\n");

# 128bit WEP
#print(MSBFILE "13\n");

# Jump over header
for ($i=0; $i<40; $i++) {
	$inchar=ord(getc(INFILE));
}

while (!eof(INFILE)) {

#print("\n\n802.11 Header:\n");
#print("\n\tFrame CTRL: ");

$inchar=ord(getc(INFILE));
#printf("%02x", $inchar);
$frametype=$inchar;
$inchar=ord(getc(INFILE));
#printf("%02x", $inchar);
$flags=$inchar;

#print("\n\tDuration: ");
for ($i=0; $i<2; $i++) {
	$inchar=ord(getc(INFILE));
#	printf("%02x", $inchar);
}


if ($frametype eq 0x08) {
#	print("\n\tData Frame:\n");
	&dataframe();

	
} else {
#	print("\n\tOther Frame - Skipping\n");
	#read to end of record [ff-ff-ff-ff -- then, read next record [jump ahead 16bytes?]
	$endpkt=0;
	while (!$endpkt) {
		$inchar=ord(getc(INFILE));
		if ($inchar eq 255) {
			$inchar=ord(getc(INFILE));	
			if ($inchar eq 255) {
				$inchar=ord(getc(INFILE));		
				if ($inchar eq 255) {
					$inchar=ord(getc(INFILE));		
					if ($inchar eq 255) {
						$endpkt=1;
					}
				}
			}
		}
	}


}
	

	# jump to next record
	for ($i=0; $i<16; $i++) {
	$inchar=ord(getc(INFILE));
	}

}

close(INFILE);
close(MSBFILE);
close(LSBFILE);
close(FULLFILE);

exit;


sub dataframe(){

#If ctrl = data



#print("\n\tDest Addr: ");
for ($i=0; $i<6; $i++) {
	$inchar=ord(getc(INFILE));
#	printf("%02x", $inchar);
}
#print("\n\tSrc Addr: ");
for ($i=0; $i<6; $i++) {
	$inchar=ord(getc(INFILE));
#	printf("%02x", $inchar);
}
#print("\n\tBSSID Addr: ");
for ($i=0; $i<6; $i++) {
	$inchar=ord(getc(INFILE));
#	printf("%02x", $inchar);
}

#print("\n");
for ($i=0; $i<2; $i++) {

$inchar=ord(getc(INFILE));
#printf("%02x", $inchar);

#print("$inchar-");
}

# ----- Start Reading Data: WEP 1st 3bytes IV, 4th should be 0, 5th should 1st encr output
#print("\nIV: ");
for ($x=0; $x<3; $x++) {
	$inchar=ord(getc(INFILE));
	$IVList[$x]=$inchar;
#	print("$inchar-");
}

#print("\nIV Options: ");
$inchar=ord(getc(INFILE));
#printf("%02x", $inchar);	

#print("\nEncr Byte1: ");

$inchar=ord(getc(INFILE));
$onebyte=$inchar;
#printf("%02x", $inchar);


if ($IVList[0] > 2 && $IVList[0] < 14 && $IVList[1] eq 255) {
	print("\t\nMatch normal order [MSB]: $IVList[0] $IVList[1] $IVList[2] $onebyte\n");
	print(MSBFILE "$IVList[0] $IVList[1] $IVList[2] $onebyte\n");
	#print("\t\nMatch normal order: $IVList[0] $IVList[1] $IVList[2]\n");

	
#} elsif ($IVList[2] > 2 && $IVList[2] < 14 && $IVList[1] eq 255) {
#	print("\t\nMatch reverse order [LSB]: $IVList[2] $IVList[1] $IVList[0] $onebyte\n");
#	print(LSBFILE "$IVList[2] $IVList[1] $IVList[0] $onebyte\n");
}

#read to end of record [kludge: look for ff-ff-ff-ff -- then, read next record [jump ahead 16bytes?]
$endpkt=0;
while (!$endpkt) {
	$inchar=ord(getc(INFILE));
	if ($inchar eq 255) {
		$inchar=ord(getc(INFILE));	
		if ($inchar eq 255) {
			$inchar=ord(getc(INFILE));		
			if ($inchar eq 255) {
				$inchar=ord(getc(INFILE));		
				if ($inchar eq 255) {
					$endpkt=1;
				}
			}
		}
	}
}

# ---------------------------------


}




#close(INFILE);
